package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import annotation.DocMetodo;
import model.CountDTO;
import model.HashtagRepository;

public class DBGetCountEveryHashtag extends LookingForHashtag {

	@DocMetodo(descrizione = "Metodo che otteniamo in output il numero occorrenze di ogni hashtag")
	public ArrayList<CountDTO> getCountEveryHashtag(ArrayList<CountDTO> arrCountHashtag, CountDTO countDTO) {
		ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)
		
		HashtagRepository hr = new HashtagRepository(); //istanzo il repository
		
		rs = hr.countEveryHashtag(); //richiamo il metodo
		
		try {
			while(rs.next()) { //next fa da puntatore per scorrere le righe del ResultSet (while perchè ci sono più righe)
				countDTO = new CountDTO(); //lo inizializzo
				countDTO.setNomeID(rs.getString("h.nome")); //prende il valore del ResultSet dalla determinata colonna db
				countDTO.setCount(rs.getInt("num_hashtag"));
				
				arrCountHashtag.add(countDTO); //aggiunge l'oggetto nell'arraylist apposito
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return arrCountHashtag;
	}
}
