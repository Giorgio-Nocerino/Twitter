package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import annotation.DocMetodo;
import model.MessaggioDTO;
import model.MessaggioRepository;

public class DBGetMessaggi {
	
	@DocMetodo(descrizione = "Metodo che otteniamo in output i messaggi dell'utente loggato e dei seguaci")
	public ArrayList<MessaggioDTO> getMsg(ArrayList<MessaggioDTO> arrMsgDTO, MessaggioDTO msgDTO, Integer idUsername){
		ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)
		
		MessaggioRepository mr = new MessaggioRepository(); //richiamo la repository

		rs = mr.getMessaggi(idUsername); //richiamo il metodo
		
		try {
			while(rs.next()) { //next fa da puntatore per scorrere le righe del ResultSet (while perchè ci sono più righe)
				msgDTO = new MessaggioDTO(); //lo inizializzo
				msgDTO.setTesto(rs.getString("m.testo")); //prende il valore del ResultSet dalla determinata colonna db
				msgDTO.setDataPub(rs.getDate("m.data_pub"));
				msgDTO.setUsername(rs.getString("u.username"));
				msgDTO.setNomeHT(rs.getString("nome_ht"));
				
				arrMsgDTO.add(msgDTO); //aggiunge l'oggetto nell'arraylist apposito
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return arrMsgDTO;
	}
}
