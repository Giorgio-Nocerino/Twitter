package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBMSConnection {

	public final static String DB_DRIVER = "com.mysql.cj.jdbc.Driver";  //carica il driver di mysql
	public final static String DB_URL = "jdbc:mysql://127.0.0.1:3306/twitter2"; //collega al localhost al db twitter2
	public final static String DB_USERNAME = "root"; //username dell'admin
	public final static String DB_PASSWORD = ""; //password dell'admin
	
	private static Connection conn = null; //variabile di tipo Connection per generare un'unica connessione
	
	public static Connection getConnection() { //ritorna la connessione privata/unica
		return conn;
	}
	
	static { //blocco statico dove ci sono sia gli attributi che i metodi statici
		try {
			Class.forName(DB_DRIVER); //preparo i driver
			
			conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD); //genero la connessione con l'url e le credenziali dell'admin
		}catch(ClassNotFoundException e1) {
			e1.printStackTrace();
		}catch(SQLException e2) {
			e2.printStackTrace();
		}
	}
	
	//UTILIZZO DEL PATTERN SINGLETON
	
	private static DBMSConnection istanza = null; //attributo istanza utile per un'unica connessione
	
	private DBMSConnection() { //costruttore privato
		
	}
	
	public static synchronized DBMSConnection getIstanza() {//questo metodo genera un'unica istanza dal costruttore privato
		if(istanza == null) {
			istanza = new DBMSConnection();
		}
		return istanza;
	}
	
	
}
