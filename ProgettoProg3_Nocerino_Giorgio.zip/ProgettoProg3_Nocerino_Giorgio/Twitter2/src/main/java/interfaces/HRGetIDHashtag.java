package interfaces;

import java.sql.ResultSet;

import model.Hashtag;

public interface HRGetIDHashtag {
	
	ResultSet getIDHashtag(Hashtag h);
}
