package interfaces;

import java.sql.ResultSet;

public interface FRSearchFollow {
	
	public ResultSet searchFollower(String userFollower, String userFollow);
}
