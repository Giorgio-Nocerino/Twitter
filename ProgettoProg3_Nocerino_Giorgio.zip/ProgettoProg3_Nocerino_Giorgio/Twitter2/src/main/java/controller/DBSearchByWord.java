package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import annotation.DocMetodo;
import model.HashtagRepository;
import model.ListDTO;
import model.MessaggioRepository;

public class DBSearchByWord {
	
	@DocMetodo(descrizione = "Metodo che otteniamo in output la lista di occorrenze di una parola desiderata")
	public ArrayList<ListDTO> getSearchByHashtag(ArrayList<ListDTO> arrListWord, ListDTO listDTO, String word) {
		ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)
		
		MessaggioRepository mr = new MessaggioRepository(); //istanzo il repository
		
		rs = mr.searchByWord(word); //richiamo il metodo
		
		try {
			while(rs.next()) { //next fa da puntatore per scorrere le righe del ResultSet (while perchè ci sono più righe)
				listDTO = new ListDTO(); //lo inizializzo
				listDTO.setNomeID(word); //prende il valore del ResultSet dalla determinata colonna db
				listDTO.setNomeUser(rs.getString("u.username"));
				listDTO.setTesto(rs.getString("m.testo"));
				
				arrListWord.add(listDTO); //aggiunge l'oggetto nell'arraylist apposito
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return arrListWord;
	} 
}
