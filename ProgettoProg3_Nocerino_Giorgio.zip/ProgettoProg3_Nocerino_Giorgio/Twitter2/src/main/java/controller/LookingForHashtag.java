package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.RequestDispatcher;
import model.CountDTO;
import model.HashtagRepository;
import model.ListDTO;

/**
 * Servlet implementation class LookingForHashtag
 */
@WebServlet("/LookingForHashtag")
public class LookingForHashtag extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LookingForHashtag() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		RequestDispatcher rd; //interfaccia che prepara la response da inviare al file html per esempio messaggi di testo, oggetti ecc...

		String hashtag = "#" + request.getParameter("string"); //prelevo la stringa dal parametro del form
		
		DBGetCountByHashtag dbGetCountByHash = new DBGetCountByHashtag();
		ArrayList<CountDTO> arrCountHashtag = new ArrayList<CountDTO>();
		CountDTO countDTO = null;
		
		arrCountHashtag = dbGetCountByHash.getCountByHashtag(arrCountHashtag, countDTO, hashtag); //ricavo il count dell'hashtag desiderato
		
		if(arrCountHashtag.size() > 0) { //se è stato almeno utilizzato una volta 
			DBSearchByHashtag dbSearchByHash = new DBSearchByHashtag();
			ArrayList<ListDTO> arrListHashtag = new ArrayList<ListDTO>();
			ListDTO listDTO = null;
			
			arrListHashtag = dbSearchByHash.getSearchByHashtag(arrListHashtag, listDTO, hashtag); //ricavo la lista delle occorrenze dell'hashtag desiderato
			
			request.setAttribute("paragraph", "Inserisci hashtag");
			request.setAttribute("titlePage", "Hashtag");
			request.setAttribute("count", arrCountHashtag);
			request.setAttribute("isThereCount", 1);
			request.setAttribute("isThereList", 1);
			request.setAttribute("list", arrListHashtag);
			request.setAttribute("title", "QUALE HASHTAG CERCHI?");
			request.setAttribute("switchServlet", 1);
			rd = request.getRequestDispatcher("LookingForHWFile.jsp");
			rd.forward(request, response);
			
		}
		else {
			request.setAttribute("paragraph", "Inserisci hashtag");
			request.setAttribute("titlePage", "Hashtag");
			request.setAttribute("count", arrCountHashtag);
			request.setAttribute("isThereCount", 0);
			request.setAttribute("isThereList", 0);
			request.setAttribute("title", "QUALE HASHTAG CERCHI?");
			request.setAttribute("switchServlet", 1);
			rd = request.getRequestDispatcher("LookingForHWFile.jsp");
			rd.forward(request, response);

		}
		
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
