package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import annotation.DocMetodo;
import interfaces.URGetIDUtente;
import interfaces.URGetUtente;
import interfaces.URGetUtenteByOnlyUsername;
import interfaces.URInsertUtente;
import util.DBMSConnection;

public class UtenteRepository extends Utente implements URInsertUtente, URGetUtente, URGetUtenteByOnlyUsername, URGetIDUtente{
	
	Connection conn = DBMSConnection.getIstanza().getConnection(); //richiamo la connessione per quell'unica istanza
	
	@Override
	@DocMetodo(descrizione = "Query DML che inserisce l'utente nella tabella utenti")
	public int insertUtente(Utente u) {

		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		int num = 0; //esito
		//query di inserimento
		String sql = "INSERT INTO `utenti`(`nome`, `cognome`, `username`, `pwd`, `tipoPermesso`, `data_nascita`, `email`, `sesso`) VALUES (?,?,?,?,?,?,?,?)";
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setString(1, u.getNome()); //setto il valore stringa indicando la pos del valore e il contenuto
			ps.setString(2,  u.getCognome());
			ps.setString(3, u.getUsername());
			ps.setString(4, u.getPassword());
			ps.setInt(5, 2); //sarà solo GUEST
			ps.setDate(6, u.getDataNascita());
			ps.setString(7, u.getEmail());
			ps.setString(8, u.getSesso());
			
			num = ps.executeUpdate(); //metodo che esegue la query DML
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato l'utente tramite username e password richiesti")
	public ResultSet getUtente(Utente u) {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //interfaccia che da come risultato una collection di righe (sorta di vista)
		String sql = "SELECT p.tipo, u.username, u.nome, u.cognome, u.sesso, u.pwd FROM utenti u JOIN permessi p ON(u.tipoPermesso=p.id) WHERE u.username=? and u.pwd=?";
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setString(1, u.getUsername()); //setto il valore stringa indicando la pos del valore e il contenuto
			ps.setString(2, u.getPassword());
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato l'utente via username desiderato")
	public ResultSet getUtenteByOnlyUsername(String username) {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //interfaccia che da come risultato una collection di righe (sorta di vista)
		String sql = "SELECT p.tipo, u.username, u.nome, u.cognome, u.sesso, u.pwd FROM utenti u JOIN permessi p ON(u.tipoPermesso=p.id) WHERE u.username=?";
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setString(1, username); //setto il valore stringa indicando la pos del valore e il contenuto
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato l'id dell'utente via username desiderato")
	public ResultSet getIDUsername(Utente u) {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //interfaccia che da come risultato una collection di righe (sorta di vista)
		String sql = "SELECT `id` FROM `utenti` WHERE `username`=?"; //query
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setString(1, u.getUsername()); //setto il valore stringa indicando la pos del valore e il contenuto
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
}
