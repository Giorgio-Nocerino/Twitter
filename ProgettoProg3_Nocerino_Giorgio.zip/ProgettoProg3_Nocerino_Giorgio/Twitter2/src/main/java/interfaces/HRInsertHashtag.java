package interfaces;

import model.Hashtag;

public interface HRInsertHashtag {

	int insertHashtag(Hashtag h);
}
