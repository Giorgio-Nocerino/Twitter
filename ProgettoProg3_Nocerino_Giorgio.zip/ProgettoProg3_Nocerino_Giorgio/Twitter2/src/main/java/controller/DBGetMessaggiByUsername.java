package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import annotation.DocMetodo;
import model.MessaggioDTO;
import model.MessaggioRepository;
import model.Utente;

public class DBGetMessaggiByUsername {
	
	@DocMetodo(descrizione = "Metodo che otteniamo in output i messaggi dell'utente dall'username")
	public ArrayList<MessaggioDTO> getMsgByUsername(ArrayList<MessaggioDTO> arrMsgDTO, MessaggioDTO msgDTO, Utente u){
		ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)
		
		MessaggioRepository mr = new MessaggioRepository(); //richiamo la repository

		rs = mr.getMessaggiByUsername(u); //richiamo il metodo
		
		try {
			while(rs.next()) { //next fa da puntatore per scorrere le righe del ResultSet (while perchè ci sono più righe)
				msgDTO = new MessaggioDTO(); //lo inizializzo
				msgDTO.setTesto(rs.getString("m.testo")); //prende il valore del ResultSet dalla determinata colonna db
				msgDTO.setDataPub(rs.getDate("m.data_pub"));
				msgDTO.setUsername(rs.getString("u.username"));
				msgDTO.setNomeHT(rs.getString("nome_ht"));
				
				arrMsgDTO.add(msgDTO); //aggiunge l'oggetto nell'arraylist apposito
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return arrMsgDTO;
	}
}
