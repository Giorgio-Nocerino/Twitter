package interfaces;

import java.sql.ResultSet;

public interface MRGetNumMsgRicevuti {
	
	ResultSet getCountNumMsgRicevuti();

}
