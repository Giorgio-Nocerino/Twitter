package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import annotation.DocMetodo;
import interfaces.HRCountByHashtag;
import interfaces.HRCountEveryHashtag;
import interfaces.HRGetIDHashtag;
import interfaces.HRInsertHashtag;
import interfaces.HRSearchByHashtag;
import util.DBMSConnection;

public class HashtagRepository implements HRInsertHashtag, HRSearchByHashtag, HRCountByHashtag, HRCountEveryHashtag, HRGetIDHashtag{

	Connection conn = DBMSConnection.getIstanza().getConnection(); //richiamo la connessione per quell'unica istanza

	@Override
	@DocMetodo(descrizione = "Query DML che inserisce l'hashtag nella tabella hashtags")
	public int insertHashtag(Hashtag h) {

		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		int num = 0; //esito
		//query di inserimento
		String sql = "INSERT INTO `hashtags`(`nome`) VALUES (?)";
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setString(1, h.getNome()); //setto il valore stringa indicando la pos del valore e il contenuto
			
			num = ps.executeUpdate(); //metodo che esegue la query DML
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato l'id dell'hashtag desiderato")
	public ResultSet getIDHashtag(Hashtag h) {

		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //esito
		//query
		String sql = "SELECT `id` FROM `hashtags` WHERE `nome` = ?";
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setString(1, h.getNome()); //setto il valore stringa indicando la pos del valore e il contenuto
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato l'hashtag desiderato")
	public ResultSet searchByHashtag(String hashtag) {
	
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //esito
	
		String sql = "SELECT u.username, h.nome, m.testo FROM messaggi m\r\n"
				+ "join hashtags h on(m.id_hashtag=h.id)\r\n"
				+ "join utenti u on(m.id_utente=u.id)\r\n"
				+ "where h.nome LIKE ?";
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setString(1, hashtag); //setto il valore stringa indicando la pos del valore e il contenuto
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato il totale occorrenze di ogni hashtag presente")
	public ResultSet countEveryHashtag() {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //esito
	
		String sql = "SELECT h.nome, count(*) as num_hashtag FROM messaggi m\r\n"
				+ "join hashtags h on(m.id_hashtag=h.id)\r\n"
				+ "join utenti u on(m.id_utente=u.id)\r\n"
				+ "GROUP BY h.nome"; //query dove ottengo quante volte sono state menzionate hashtag presenti
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
						
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato il totale occorrenze dell'hashtag desiderato")
	public ResultSet countByHashtag(String hashtag) {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //esito
	
		String sql = "SELECT h.nome, count(*) as num_hashtag FROM messaggi m\r\n"
				+ "join hashtags h on(m.id_hashtag=h.id)\r\n"
				+ "join utenti u on(m.id_utente=u.id)\r\n"
				+ "where h.nome LIKE ?\r\n"
				+ "GROUP BY h.nome";  //query dove ottiene il totale di quante volte è stato utilizzato l'hashtag
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
						
			ps.setString(1, hashtag); //setto il valore stringa indicando la pos del valore e il contenuto
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
}
