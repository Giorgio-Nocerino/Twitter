package model;

import java.sql.Date;
import java.util.Objects;

public class Messaggio {
	private String testo;
	private Date dataPub;
	
	
	public String getTesto() {
		return testo;
	}
	public void setTesto(String testo) {
		this.testo = testo;
	}
	public Date getDataPub() {
		return dataPub;
	}
	public void setDataPub(Date dataPub) {
		this.dataPub = dataPub;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(dataPub, testo);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Messaggio other = (Messaggio) obj;
		return Objects.equals(dataPub, other.dataPub) && Objects.equals(testo, other.testo);
	}
	public Messaggio() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Messaggio(String testo, Date dataPub) {
		super();
		this.testo = testo;
		this.dataPub = dataPub;
	}
	
	
}
