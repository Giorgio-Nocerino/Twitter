package controller;

import java.sql.ResultSet;
import java.sql.SQLException;

import annotation.DocMetodo;
import model.FollowerRepository;

public class DBSearchFollow {

	@DocMetodo(descrizione="Metodo che restituisce l'id del follow dal follower")
	public Integer searchFollow(String userFollower, String userFollow){
		ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)
		
		FollowerRepository fr = new FollowerRepository(); //richiamo la repository

		rs = fr.searchFollower(userFollower, userFollow); //richiamo il metodo
		Integer idFollow = 0;
		
		try {
			if(rs.next()) { //next fa da puntatore per scorrere le righe del ResultSet (if perchè c'è una sola riga)
				idFollow = rs.getInt("f.id_utente_follow"); //prende il valore del ResultSet dalla determinata colonna db				
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return idFollow;
	}
}
