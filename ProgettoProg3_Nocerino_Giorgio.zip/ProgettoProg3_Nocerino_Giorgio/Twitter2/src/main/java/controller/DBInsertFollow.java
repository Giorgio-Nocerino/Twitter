package controller;

import annotation.DocMetodo;
import model.FollowerRepository;

public class DBInsertFollow {

	@DocMetodo(descrizione="Metodo che inserisce il follower in base all'id follower e follow")
	public Integer insertFollow(Integer idUserFollower, Integer idUserFollow) {
		
		FollowerRepository fr = new FollowerRepository();
		Integer num = 0;
		
		num = fr.insertFollow(idUserFollower, idUserFollow); //richiamo il metodo passando sia l'id del follower che del follow
		
		return num;
	}
}
