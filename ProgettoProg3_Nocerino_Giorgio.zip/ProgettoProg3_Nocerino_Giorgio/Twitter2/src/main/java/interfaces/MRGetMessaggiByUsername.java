package interfaces;

import java.sql.ResultSet;

import model.Utente;

public interface MRGetMessaggiByUsername {
	
	ResultSet getMessaggiByUsername(Utente u);
}
