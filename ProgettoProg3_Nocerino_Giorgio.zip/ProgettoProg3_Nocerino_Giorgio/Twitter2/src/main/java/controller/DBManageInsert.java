package controller;

import annotation.DocMetodo;
import model.*;

public class DBManageInsert {

	@DocMetodo(descrizione = "Metodo che gestisce l'inserimento nelle determinate tabelle in base al tipo di Object")
	public int insertIntoUHM(Object obj, Integer idUser, Integer idHash) {
		
		int num = 0;
		
		if(obj instanceof Utente) {
			Utente u = (Utente) obj;
			UtenteRepository ur = new UtenteRepository();
			
			num = ur.insertUtente(u);
			
		}
		else if(obj instanceof Hashtag) {
			Hashtag h = (Hashtag) obj;
			HashtagRepository hr = new HashtagRepository();
			
			num = hr.insertHashtag(h);
		}
		else {
			Messaggio m = (Messaggio) obj;
			MessaggioRepository mr = new MessaggioRepository();
			
			num = mr.insertMessaggio(m, idUser, idHash);
		}
		
		return num;
	}
}
