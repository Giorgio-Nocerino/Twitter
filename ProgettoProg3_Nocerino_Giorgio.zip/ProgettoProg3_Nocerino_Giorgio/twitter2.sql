-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mar 01, 2024 alle 13:28
-- Versione del server: 10.4.28-MariaDB
-- Versione PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `twitter2`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `followers`
--

CREATE TABLE `followers` (
  `id` int(11) NOT NULL,
  `id_utente_followed` int(11) DEFAULT NULL,
  `id_utente_follow` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `followers`
--

INSERT INTO `followers` (`id`, `id_utente_followed`, `id_utente_follow`) VALUES
(4, 1, 5),
(6, 4, 1),
(7, 1, 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `hashtags`
--

CREATE TABLE `hashtags` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `hashtags`
--

INSERT INTO `hashtags` (`id`, `nome`) VALUES
(1, '#FIRSTIMETWITTER2'),
(2, '#LETSEE'),
(3, ''),
(4, '#ALMOSTWEEKEND'),
(5, '#ENESPANOL'),
(6, '#NEWENTRY'),
(7, '#DINUOVOQUI');

-- --------------------------------------------------------

--
-- Struttura della tabella `messaggi`
--

CREATE TABLE `messaggi` (
  `id` int(11) NOT NULL,
  `testo` varchar(140) DEFAULT NULL,
  `id_utente` int(11) NOT NULL,
  `id_hashtag` int(11) NOT NULL,
  `data_pub` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `messaggi`
--

INSERT INTO `messaggi` (`id`, `testo`, `id_utente`, `id_hashtag`, `data_pub`) VALUES
(1, 'Ciaooo io sono George e sto usando TWITTER2', 1, 1, '2024-01-13'),
(2, 'Seconda volta', 1, 1, '2021-01-14'),
(3, 'Speriamo che funziona', 1, 2, '2024-01-20'),
(4, 'vediamo', 1, 2, '2024-01-20'),
(5, 'vediamo', 1, 2, '2024-01-20'),
(6, 'Ora si che funziona', 1, 2, '2024-01-20'),
(10, 'Un\'altra settimana sta per volare', 1, 4, '2024-02-15'),
(11, 'Espera! Yo soy Juarez', 1, 5, '2024-02-15'),
(12, 'Ciaoo, io sono Chiaraa', 5, 6, '2024-02-17'),
(13, 'Ciaoo io sono Alex, bff di Giorgio', 4, 6, '2024-02-17'),
(14, 'CIAOOO', 4, 7, '2024-02-24');

-- --------------------------------------------------------

--
-- Struttura della tabella `permessi`
--

CREATE TABLE `permessi` (
  `id` int(11) NOT NULL,
  `tipo` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `permessi`
--

INSERT INTO `permessi` (`id`, `tipo`) VALUES
(1, 'ADMIN'),
(2, 'GUEST');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `nome` varchar(60) NOT NULL,
  `cognome` varchar(70) NOT NULL,
  `username` varchar(70) NOT NULL,
  `pwd` varchar(70) NOT NULL,
  `tipoPermesso` int(11) NOT NULL,
  `data_nascita` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `sesso` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `nome`, `cognome`, `username`, `pwd`, `tipoPermesso`, `data_nascita`, `email`, `sesso`) VALUES
(1, 'Giorgio', 'Nocerino', 'Georez', 'Georez#342', 1, '0000-00-00', 'giorgionocerino01@gmail.com', 'M'),
(3, 'Gennaro', 'Nocerino', 'gennykiller', 'gennykiller', 2, '2005-05-25', 'gennaro@gmail.com', 'M'),
(4, 'Alessandro', 'Di Stefano', 'AlexDiSte', 'Alexdiste#3', 2, '2012-01-31', 'alexdiste@gmail.com', 'M'),
(5, 'Chiara', 'Arrivas', 'EllaArrivas', 'Ella#342', 2, '2010-05-13', 'chiararrivas@gmail.com', 'F');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_utente_followed` (`id_utente_followed`),
  ADD KEY `id_utente_follow` (`id_utente_follow`);

--
-- Indici per le tabelle `hashtags`
--
ALTER TABLE `hashtags`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `messaggi`
--
ALTER TABLE `messaggi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_utente` (`id_utente`),
  ADD KEY `id_hashtag` (`id_hashtag`);

--
-- Indici per le tabelle `permessi`
--
ALTER TABLE `permessi`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tipoPermesso` (`tipoPermesso`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `followers`
--
ALTER TABLE `followers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT per la tabella `hashtags`
--
ALTER TABLE `hashtags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT per la tabella `messaggi`
--
ALTER TABLE `messaggi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT per la tabella `permessi`
--
ALTER TABLE `permessi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `followers`
--
ALTER TABLE `followers`
  ADD CONSTRAINT `followers_ibfk_1` FOREIGN KEY (`id_utente_followed`) REFERENCES `utenti` (`id`),
  ADD CONSTRAINT `followers_ibfk_2` FOREIGN KEY (`id_utente_follow`) REFERENCES `utenti` (`id`);

--
-- Limiti per la tabella `messaggi`
--
ALTER TABLE `messaggi`
  ADD CONSTRAINT `messaggi_ibfk_1` FOREIGN KEY (`id_utente`) REFERENCES `utenti` (`id`),
  ADD CONSTRAINT `messaggi_ibfk_2` FOREIGN KEY (`id_hashtag`) REFERENCES `hashtags` (`id`);

--
-- Limiti per la tabella `utenti`
--
ALTER TABLE `utenti`
  ADD CONSTRAINT `utenti_ibfk_1` FOREIGN KEY (`tipoPermesso`) REFERENCES `permessi` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
