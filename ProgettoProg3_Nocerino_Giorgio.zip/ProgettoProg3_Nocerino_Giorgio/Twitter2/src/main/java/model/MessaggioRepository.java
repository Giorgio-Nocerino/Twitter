package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import annotation.DocMetodo;
import interfaces.MRCountByWord;
import interfaces.MRGetMessaggi;
import interfaces.MRGetMessaggiByUsername;
import interfaces.MRGetNumMsgInviati;
import interfaces.MRGetNumMsgRicevuti;
import interfaces.MRInsertMessaggio;
import interfaces.MRSearchByWord;
import util.DBMSConnection;

public class MessaggioRepository implements MRInsertMessaggio, MRGetMessaggi, MRGetMessaggiByUsername, MRCountByWord, MRSearchByWord, MRGetNumMsgInviati, MRGetNumMsgRicevuti {

	
	Connection conn = DBMSConnection.getIstanza().getConnection(); //richiamo la connessione per quell'unica istanza

	@Override
	@DocMetodo(descrizione = "Query DML che inserisce il messaggio alla tabella messaggi")
	public int insertMessaggio(Messaggio m, Integer idUsername, Integer idHashtag) {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		int num = 0; //esito
		//query di inserimento
		String sql = "INSERT INTO `messaggi`(`testo`, `data_pub`, `id_utente`, `id_hashtag`) VALUES (?,?,?,?)";
		
		try {//potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setString(1, m.getTesto()); //setto il valore stringa indicando la pos del valore e il contenuto
			ps.setDate(2, m.getDataPub());
			ps.setInt(3, idUsername);
			ps.setInt(4, idHashtag);

			num = ps.executeUpdate();//metodo che esegue la query DML
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return num;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato una lista di messaggi sia dell'utente e quelli che segue in ordine decrescente")
	public ResultSet getMessaggi(Integer idUsernameFollower) {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //interfaccia che da come risultato una collection di righe (sorta di vista)
		//query per far uscire i messaggi
		String sql = "SELECT m.testo, u.username, h.nome as nome_ht, m.data_pub \r\n"
				+ "FROM messaggi m join utenti u on(m.id_utente=u.id) \r\n"
				+ "join hashtags h on(m.id_hashtag=h.id) \r\n"
				+ "where m.id_utente=? or m.id_utente in (select f.id_utente_follow from followers f\r\n"
				+ "where f.id_utente_followed=?) order by m.data_pub desc";
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setInt(1, idUsernameFollower);
			ps.setInt(2, idUsernameFollower);
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato la lista di messaggi via username")
	public ResultSet getMessaggiByUsername(Utente u) {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //interfaccia che da come risultato una collection di righe (sorta di vista)
		//query per far uscire i messaggi
		String sql = "SELECT m.testo, u.username, h.nome as nome_ht, m.data_pub FROM messaggi m join utenti u on(m.id_utente=u.id) join hashtags h on(m.id_hashtag=h.id) where u.username = ? ORDER BY m.data_pub DESC";
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setString(1, u.getUsername());
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato il totale occorrenze della parola desiderata")
	public ResultSet countByWord(String word) {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //esito
	
		String sql = "select count(*) as num_parola from messaggi m\r\n"
				+ "join utenti u on (m.id_utente=u.id)\r\n"
				+ "where m.testo like ?"; //query dove conta quante volte nei messaggi è stata utilizzata la parola
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
						
			ps.setString(1, word); //setto il valore stringa indicando la pos del valore e il contenuto
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato la lista dei messaggi che contiene la parola desiderata")
	public ResultSet searchByWord(String word) {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //esito
	
		String sql = "select m.testo, u.username from messaggi m JOIN\r\n"
				+ "utenti u on(m.id_utente=u.id)\r\n"
				+ "where m.testo like ?"; //query dove conta quante volte nei messaggi è stata utilizzata la parola
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
						
			ps.setString(1, word); //setto il valore stringa indicando la pos del valore e il contenuto
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato l'username e il suo numero di messaggi inviati")
	public ResultSet getCountNumMsgInviati() {
		// TODO Auto-generated method stub
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //esito
	
		String sql = "SELECT u.username, count(*) as num_msg_inviati\r\n"
				+ "FROM messaggi m join utenti u on(m.id_utente=u.id) \r\n"
				+ "join hashtags h on(m.id_hashtag=h.id) \r\n"
				+ "group by u.username"; //query dove si ottiene l'username e il suo numero di messaggi inviati
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
									
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	@Override
	@DocMetodo(descrizione = "Query DQL che dà come risultato l'username e il suo numero di messaggi ricevuti")
	public ResultSet getCountNumMsgRicevuti() {
		// TODO Auto-generated method stub
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //esito
	
		String sql = "SELECT u.username, count(*) AS num_msg_ricevuti\r\n"
				+ "FROM followers f\r\n"
				+ "JOIN utenti u on(f.id_utente_followed = u.id)\r\n"
				+ "JOIN messaggi m on(m.id_utente = f.id_utente_follow)\r\n"
				+ "JOIN hashtags h on(m.id_hashtag=h.id)\r\n"
				+ "GROUP BY u.username"; //query dove si ottiene l'username e il suo numero di messaggi ricevuti
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
									
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
}
