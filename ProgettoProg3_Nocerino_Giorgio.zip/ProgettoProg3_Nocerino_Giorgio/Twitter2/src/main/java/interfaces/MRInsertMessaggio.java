package interfaces;

import model.Messaggio;

public interface MRInsertMessaggio {
	int insertMessaggio(Messaggio m, Integer idUsername, Integer idHashtag);
}
