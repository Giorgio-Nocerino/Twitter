package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import annotation.DocMetodo;
import model.CountDTO;
import model.HashtagRepository;
import model.ListDTO;

public class DBSearchByHashtag extends LookingForHashtag {

	@DocMetodo(descrizione = "Metodo che otteniamo in output la lista di occorrenze di un hashtag desiderato")
	public ArrayList<ListDTO> getSearchByHashtag(ArrayList<ListDTO> arrListHashtag, ListDTO listDTO, String hashtag) {
		ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)
		
		HashtagRepository hr = new HashtagRepository(); //istanzo il repository
		
		rs = hr.searchByHashtag(hashtag); //richiamo il metodo
		
		try {
			while(rs.next()) { //next fa da puntatore per scorrere le righe del ResultSet (while perchè ci sono più righe)
				listDTO = new ListDTO(); //lo inizializzo
				listDTO.setNomeID(rs.getString("h.nome")); //prende il valore del ResultSet dalla determinata colonna db
				listDTO.setNomeUser(rs.getString("u.username"));
				listDTO.setTesto(rs.getString("m.testo"));
				
				arrListHashtag.add(listDTO); //aggiunge l'oggetto nell'arraylist apposito
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return arrListHashtag;
	} 
}
