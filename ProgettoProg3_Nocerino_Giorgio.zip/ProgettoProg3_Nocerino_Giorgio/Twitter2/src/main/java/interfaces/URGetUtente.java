package interfaces;

import java.sql.ResultSet;

import model.Utente;

public interface URGetUtente {
	ResultSet getUtente(Utente u);
}
