package model;

import java.sql.Date;
import java.util.Objects;

public class Utente extends Persona{
	
	private String username;
	private String email;
	private String password;
	private String tipoPermesso;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTipoPermesso() {
		return tipoPermesso;
	}
	public void setTipoPermesso(String tipoPermesso) {
		this.tipoPermesso = tipoPermesso;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(email, password, tipoPermesso, username);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Utente other = (Utente) obj;
		return Objects.equals(password, other.password)
				&& Objects.equals(tipoPermesso, other.tipoPermesso) && Objects.equals(username, other.username)
				&& Objects.equals(email, other.email);
	}
	public Utente() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Utente(String nome, String cognome, String sesso, String username, String email, String password, String tipoPermesso, Date dataNascita) {
		super(nome, cognome, sesso, dataNascita);
		this.username = username;
		this.email = email;
		this.password = password;
		this.tipoPermesso = tipoPermesso;
	}
	
	
	

}
