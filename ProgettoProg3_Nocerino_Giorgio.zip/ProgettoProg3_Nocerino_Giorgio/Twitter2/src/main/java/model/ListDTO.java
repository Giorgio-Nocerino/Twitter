package model;

import java.util.Objects;

public class ListDTO {

	private String nomeUser;
	private String nomeID;
	private String testo;
	public String getNomeUser() {
		return nomeUser;
	}
	public void setNomeUser(String nomeUser) {
		this.nomeUser = nomeUser;
	}
	
	public String getNomeID() {
		return nomeID;
	}
	public void setNomeID(String nomeID) {
		this.nomeID = nomeID;
	}
	public String getTesto() {
		return testo;
	}
	public void setTesto(String testo) {
		this.testo = testo;
	}
	@Override
	public int hashCode() {
		return Objects.hash(nomeID, nomeUser, testo);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ListDTO other = (ListDTO) obj;
		return Objects.equals(nomeID, other.nomeID) && Objects.equals(nomeUser, other.nomeUser)
				&& Objects.equals(testo, other.testo);
	}
	
	
	
	public ListDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ListDTO(String nomeUser, String nomeID, String testo) {
		super();
		this.nomeUser = nomeUser;
		this.nomeID = nomeID;
		this.testo = testo;
	}
	
	
}
