package interfaces;

import model.Utente;

public interface URInsertUtente {

	int insertUtente(Utente u);
}
