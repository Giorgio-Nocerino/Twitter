ATTENZIONE

Per avviare il progetto Twitter2, è necessario installare il programma XAMPP recando in questo sito

https://www.apachefriends.org/it/index.html

Una volta installato, accendere le connessioni Apache e MySQL

Recarsi, nel localhost phpMyAdmin e caricare il file sql twitter2 nella sezione Importa, cosi da creare il DB e le rispettive tabelle con all'interno i dati

Installare l'ultima versione di TOMCAT e posizionarlo in una qualsiasi directory

in Eclipse:

Configurare il progetto, andando nella sezione servers, in basso, fare tasto dx -> new, scegliere la versione di tomcat -> selezionare tomcat nella directory e finish

A questo punto, premere PLAY

Buon divertimento :-)
