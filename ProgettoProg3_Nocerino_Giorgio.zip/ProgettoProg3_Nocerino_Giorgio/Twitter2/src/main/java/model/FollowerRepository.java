package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import annotation.DocMetodo;
import interfaces.FRInsertFollow;
import interfaces.FRSearchFollow;
import util.DBMSConnection;

public class FollowerRepository implements FRInsertFollow, FRSearchFollow {

	Connection conn = DBMSConnection.getIstanza().getConnection(); //richiamo la connessione per quell'unica istanza

	@Override
	@DocMetodo(descrizione = "Query DML che inserisce l'id del follower e l'id del follow nella tabella followers")
	public int insertFollow(Integer idFollower, Integer idFollow) {
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		int num = 0; //esito
		//query di inserimento
		String sql = "INSERT INTO `followers`(`id_utente_followed`, `id_utente_follow`) VALUES (?,?)";
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
			
			ps.setInt(1, idFollower); //setto il valore Integer indicando la pos del valore e il contenuto
			ps.setInt(2, idFollow);
			
			num = ps.executeUpdate(); //metodo che esegue la query DML
			
		}catch(SQLException e) {
			e.printStackTrace(); //genera un eccezione in caso di errore
		}
		
		return num;
	}

	@Override
	@DocMetodo(descrizione = "Query DQL che restituisce l'id del follower in base al ")
	public ResultSet searchFollower(String userFollower, String userFollow) {
		// TODO Auto-generated method stub
		PreparedStatement ps; //interfaccia che prepara lo statement (query)
		ResultSet rs = null; //esito
	
		String sql = "SELECT f.id_utente_follow \r\n"
				+ "from utenti u1 join followers f on(u1.id=f.id_utente_followed)\r\n"
				+ "join utenti u2 on(u2.id=f.id_utente_follow)\r\n"
				+ "where u1.username=? and u2.username=?";  //query dove ottiene il totale di quante volte è stato utilizzato l'hashtag
		
		try { //potrebbe generare un eccezione
			ps = conn.prepareStatement(sql); //trasformo la stringa in una vera e propria query
						
			ps.setString(1, userFollower); //setto il valore stringa indicando la pos del valore e il contenuto
			ps.setString(2, userFollow);
			
			rs = ps.executeQuery(); //metodo che esegue la query DQL
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
		
	}

	
	
}
