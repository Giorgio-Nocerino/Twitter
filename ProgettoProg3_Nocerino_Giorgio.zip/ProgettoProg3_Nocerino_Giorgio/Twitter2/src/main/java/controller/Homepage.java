package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.MessaggioDTO;
import model.MessaggioRepository;
import model.Utente;

/**
 * Servlet implementation class Homepage
 */
@WebServlet("/Homepage")
public class Homepage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Homepage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession(); //richiamo la sessione precedentemente creata

		Utente u = new Utente();
		DBManageGetID dbIDUtente;
		DBGetMessaggi dbGetMsg;
		RequestDispatcher rd; //interfaccia che prepara la response da inviare al file html per esempio messaggi di testo, oggetti ecc...
		
		u = (Utente) session.getAttribute("user"); //recupero il valore della session con il metodo getAttribute e lo casto a Utente
		
		if(u != null) {
			MessaggioRepository mr = new MessaggioRepository(); //richiamo la repository
			MessaggioDTO msgDTO = null; //creo la var Messaggio ma non lo inizializzo
			ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)
			
			ArrayList<MessaggioDTO> arrMsgDTO = new ArrayList<MessaggioDTO>();
			dbIDUtente = new DBManageGetID(); 
			
			Integer idUsername = dbIDUtente.getID(u);
			
			dbGetMsg = new DBGetMessaggi();
			arrMsgDTO = dbGetMsg.getMsg(arrMsgDTO, msgDTO, idUsername); //richiamo il metodo per ottenere i messaggi
			
			
			request.setAttribute("arrMsgDTO", arrMsgDTO); //preparo il messaggio dove contiene l'arraylist
			rd = request.getRequestDispatcher("HomepageFile.jsp");
			rd.forward(request, response);
			
		}
		else {
			request.setAttribute("msg", "ERRORE SESSION"); //se la sessione per qualche motivo non è presente, allora ti rispedisce nella pagina d'accesso
			rd = request.getRequestDispatcher("FailLogin.jsp");
			rd.forward(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
