package interfaces;

import java.sql.ResultSet;

import model.Utente;

public interface URGetIDUtente {
	
	ResultSet getIDUsername(Utente u);
}
