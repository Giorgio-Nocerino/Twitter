package controller;

import java.sql.ResultSet;
import java.sql.SQLException;

import annotation.DocMetodo;
import model.FollowerRepository;
import model.Hashtag;
import model.HashtagRepository;
import model.Utente;
import model.UtenteRepository;

public class DBManageGetID {
	
	@DocMetodo(descrizione = "Metodo che gestisce l'ottenimento dell'ID dalle determinate tabelle in base al tipo di Object")
	public Integer getID(Object obj) {
		ResultSet rs = null;
		Integer idObj = 0;
		
		
		if(obj instanceof Utente) { //controlla se la var Object ha l'istanza di Utente
			UtenteRepository ur = new UtenteRepository();
			Utente u = (Utente) obj; //lo casta
			rs = ur.getIDUsername(u); //recupero l'id dell'username
			
			
			try {
				if(rs.next()) {  //next fa da puntatore per scorrere le righe del ResultSet (if perchè c'è una sola riga)
					idObj = rs.getInt("id");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		else if(obj instanceof Hashtag) {//controlla se la var Object ha l'istanza di Hashtag
			HashtagRepository hr = new HashtagRepository();
			Hashtag h = (Hashtag) obj; //lo casta
			rs = hr.getIDHashtag(h); //recupero l'id di hashtaf
			
			
			try {
				if(rs.next()) {  //next fa da puntatore per scorrere le righe del ResultSet (if perchè c'è una sola riga)
					idObj = rs.getInt("id");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		return idObj;
	}
	
}
