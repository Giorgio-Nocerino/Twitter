package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.MessaggioDTO;
import model.MessaggioRepository;
import model.Utente;

/**
 * Servlet implementation class Profile
 */
@WebServlet("/Profile")
public class Profile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Profile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession(); //richiamo la sessione precedentemente creata

		Utente u = new Utente();
		RequestDispatcher rd; //interfaccia che prepara la response da inviare al file html per esempio messaggi di testo, oggetti ecc...
		
		u = (Utente) session.getAttribute("user"); //recupero il valore della session con il metodo getAttribute e lo casto a Utente
		
		if(u != null) {
			MessaggioDTO msgDTO = null; //creo la var Messaggio ma non lo inizializzo
			DBGetMessaggiByUsername dbMsgbyUser = new DBGetMessaggiByUsername();
			
			ArrayList<MessaggioDTO> arrMsgDTO = new ArrayList<MessaggioDTO>();
			
			arrMsgDTO = dbMsgbyUser.getMsgByUsername(arrMsgDTO, msgDTO, u); //richiamo il metodo per ottenere l'utenre via username
			
			request.setAttribute("arrMsgDTO", arrMsgDTO); //preparo il messaggio dove contiene l'arraylist
			request.setAttribute("person", u);
			request.setAttribute("val", 1);
			rd = request.getRequestDispatcher("ProfileFile.jsp");
			rd.forward(request, response);
			
		}
		else {
			request.setAttribute("val", 0);
			rd = request.getRequestDispatcher("ProfileFile.jsp");
			rd.forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
