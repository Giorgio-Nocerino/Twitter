package annotation;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME) //annotation applicato all'esecuzione del programma
@Target(ElementType.METHOD) //valido solo per i metodi
public @interface DocMetodo {
	String descrizione() default "No descrizione";
}
