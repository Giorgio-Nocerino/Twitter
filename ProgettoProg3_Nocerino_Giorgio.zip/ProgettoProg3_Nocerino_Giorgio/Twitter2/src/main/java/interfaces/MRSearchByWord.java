package interfaces;

import java.sql.ResultSet;

public interface MRSearchByWord {
	ResultSet searchByWord(String word);
}
