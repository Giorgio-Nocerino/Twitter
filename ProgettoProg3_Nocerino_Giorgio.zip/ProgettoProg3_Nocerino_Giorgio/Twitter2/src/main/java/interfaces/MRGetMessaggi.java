package interfaces;

import java.sql.ResultSet;

public interface MRGetMessaggi {

	ResultSet getMessaggi(Integer idUsernameFollower);
}
