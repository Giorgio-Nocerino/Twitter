package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.CountDTO;
import model.HashtagRepository;
import model.ListDTO;
import model.MessaggioRepository;

/**
 * Servlet implementation class LookingForWord
 */
@WebServlet("/LookingForWord")
public class LookingForWord extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LookingForWord() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd; //interfaccia che prepara la response da inviare al file html per esempio messaggi di testo, oggetti ecc...

		String word = "%" + request.getParameter("string") + "%"; //prelevo la stringa dal parametro del form
		
		DBGetCountByWord dbGetCountByWord = new DBGetCountByWord();
		ArrayList<CountDTO> arrCountWord = new ArrayList<CountDTO>();
		CountDTO countDTO = null;
		
		arrCountWord = dbGetCountByWord.getCountByWord(arrCountWord, countDTO, word); //ricavo il count della parola desiderata
		
		if(arrCountWord.size() > 0) { //se è stato almeno utilizzato una volta 
			DBSearchByWord dbSearchByWord = new DBSearchByWord();
			ArrayList<ListDTO> arrListWord = new ArrayList<ListDTO>();
			ListDTO listDTO = null;
			
			arrListWord = dbSearchByWord.getSearchByHashtag(arrListWord, listDTO, word); //ricavo la lista delle occorrenze della parola desiderata
			
			request.setAttribute("paragraph", "Inserisci la parola");
			request.setAttribute("titlePage", "Word");
			request.setAttribute("count", arrCountWord);
			request.setAttribute("isThereCount", 1);
			request.setAttribute("isThereList", 1);
			request.setAttribute("list", arrListWord);
			request.setAttribute("title", "QUALE PAROLA CERCHI?");
			request.setAttribute("switchServlet", 2);
			rd = request.getRequestDispatcher("LookingForHWFile.jsp");
			rd.forward(request, response);
			
		}
		else {
			request.setAttribute("paragraph", "Inserisci la parola");
			request.setAttribute("titlePage", "Word");
			request.setAttribute("count", arrCountWord);
			request.setAttribute("isThereCount", 0);
			request.setAttribute("isThereList", 0);
			request.setAttribute("title", "QUALE PAROLA CERCHI?");
			request.setAttribute("switchServlet", 2);
			rd = request.getRequestDispatcher("LookingForHWFile.jsp");
			rd.forward(request, response);

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
