package interfaces;

import java.sql.ResultSet;

public interface HRCountByHashtag {
	ResultSet countByHashtag(String hashtag);
}
