package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.MessaggioDTO;
import model.MessaggioRepository;
import model.Utente;
import model.UtenteRepository;

/**
 * Servlet implementation class LookingFor
 */
@WebServlet("/LookingForUser")
public class LookingForUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LookingForUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Utente u = new Utente();
		HttpSession session = request.getSession(); //preparo la sessione così i dati persisteranno
		DBGetUtenteByUsername dbGetUtentebyUsername = new DBGetUtenteByUsername();
		RequestDispatcher rd; //interfaccia che prepara la response da inviare al file html per esempio messaggi di testo, oggetti ecc...
		
		String usernameFollow = request.getParameter("username"); //recupero il valore dal parametro username con il metodo getParameter
		
		u = dbGetUtentebyUsername.getUtenteByUsername(usernameFollow); //ricavo l'utente in base all'username
		
		Utente userSession = (Utente) session.getAttribute("user"); //recupero il valore della session con il metodo getAttribute e lo casto a Utente

		
		if(!u.getUsername().equals(null) && userSession != null) { //se l'username trovato non è nullo e la sessione dell'utente loggata non è staccata
			MessaggioDTO msgDTO = null; //creo la var Messaggio ma non lo inizializzo
			DBGetMessaggiByUsername dbGetMsgByUsername = new DBGetMessaggiByUsername();
			DBSearchFollow dbSearchFollow = new DBSearchFollow();
			
			ArrayList<MessaggioDTO> arrMsgDTO = new ArrayList<MessaggioDTO>();
			
			arrMsgDTO = dbGetMsgByUsername.getMsgByUsername(arrMsgDTO, msgDTO, u); //ricavo i messaggi in base all'username
			Integer idFollow = 0;
			
			idFollow = dbSearchFollow.searchFollow(userSession.getUsername(), usernameFollow); //ricavo l'id del follow
			
			request.setAttribute("arrMsgDTO", arrMsgDTO); //preparo il messaggio dove contiene l'arraylist
			request.setAttribute("person", u);
			request.setAttribute("youFollow", idFollow);
			rd = request.getRequestDispatcher("ProfileFile.jsp");
			rd.forward(request, response);
			
		}
		else {
			request.setAttribute("msg", "NESSUN RISULTATO");
			rd = request.getRequestDispatcher("Fail.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
