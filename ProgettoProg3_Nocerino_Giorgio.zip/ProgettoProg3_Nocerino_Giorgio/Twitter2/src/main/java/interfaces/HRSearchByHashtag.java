package interfaces;

import java.sql.ResultSet;

public interface HRSearchByHashtag {
	ResultSet searchByHashtag(String hashtag);
}
