package interfaces;

import java.sql.ResultSet;

public interface MRCountByWord {
	ResultSet countByWord(String word);
}
