package controller;

import java.io.IOException;
import java.sql.Date;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Utente;
import model.UtenteRepository;
/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Utente u = new Utente(); //creo la var con l'istanza dell'utente
		DBManageInsert dm = new DBManageInsert();  //creo la var con l'istanza del repository
		
		u.setNome(request.getParameter("name"));
		u.setCognome(request.getParameter("surname"));
		u.setSesso(request.getParameter("sex"));
		u.setDataNascita(Date.valueOf(request.getParameter("birthDate")));
		u.setUsername(request.getParameter("username")); //metodo che prende i valori dal parametro (attributo name del tag input)
		u.setEmail(request.getParameter("email"));
		u.setPassword(request.getParameter("password"));
		
		int num = 0;
		
		num = dm.insertIntoUHM(u, null, null);
		
		RequestDispatcher rd; //interfaccia che prepara la response da inviare al file html per esempio messaggi di testo, oggetti ecc...
		
		if(num > 0) { //se è stato aggiunto nel db allora preparo il messaggio
			request.setAttribute("msg", "REGISTRAZIONE EFFETTUATA CON SUCCESSO");
			rd = request.getRequestDispatcher("SuccessRegister.jsp");
			rd.forward(request, response);
		}
		else {
			request.setAttribute("msg", "REGISTRAZIONE FALLITA");
			rd = request.getRequestDispatcher("FailRegister.jsp");
			rd.forward(request, response);
		}
	}

}
