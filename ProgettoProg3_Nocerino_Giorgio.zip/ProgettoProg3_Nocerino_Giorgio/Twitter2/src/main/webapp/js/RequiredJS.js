/**
 * 
 */

 //qui creerò le funzioni JS per il controllo dell'insert dei campi Register
 
 
 function checkName(){ //funzione che controlla l'inserimento del nome
	 var name = document.form.name; //creo la variabile dove vado a passare l'input (radice è document, form sarebbe nome del form, name sarebbe il nome dell'attr di input)
	 var check = new RegExp('^[a-z]{3,60}$', 'i'); //creo un'altra variabile che funge da check, grazie alla funzione che permette di fare pattern all'insert (^ inizio, [a-z] contenuto, {3} lunghezza, $ fine, i maiusc/minusc)
	 var error = document.getElementsByClassName("eName"); //creo la var che funge da errore prendendo via l'attr id l'elemento span
	 
	 if(!check.test(name.value)){ //praticamente controlla (con la var check e la funzione test) se il valore (value) della var rispetta la funzione RegExp
	 	error[0].innerHTML = "Deve avere un max di 60 caratteri"; //dentro a span con la funzione innerHTML scrive quello che passi come stringa
	 	error[0].style.color = "#DC5959"; //lo stilizza con un colore hex
		return false; //e ritorna false
	 }
	 else{ //nel caso rispetta i caratteri di RegExp
		 error[0].innerHTML = "Corretto";
		 error[0].style.color = "darkgreen";
		 return true; //qui ritorna true
	 }
 }
 
 function checkSurname(){ //funzione che controlla l'inserimento del cognome
	 var surname = document.form.surname; //creo la variabile dove vado a passare l'input (radice è document, form sarebbe nome del form, surname sarebbe il nome dell'attr di input)
	 var check = new RegExp('^[a-z]{3,100}$', 'i'); //creo un'altra variabile che funge da check, grazie alla funzione che permette di fare pattern all'insert (^ inizio, [a-z] contenuto, {3} lunghezza, $ fine, i maiusc/minusc)
	 var error = document.getElementsByClassName("eSurname"); //creo la var che funge da errore prendendo via l'attr id l'elemento span
	 
	 if(!check.test(surname.value)){ //praticamente controlla (con la var check e la funzione test) se il valore (value) della var rispetta la funzione RegExp
	 	error[0].innerHTML = "Deve avere un max di 100 caratteri"; //dentro a span con la funzione innerHTML scrive quello che passi come stringa
	 	error[0].style.color = "#DC5959"; //lo stilizza con un colore hex
		return false; //e ritorna false
	 }
	 else{ //nel caso rispetta i caratteri di RegExp
		 error[0].innerHTML = "Corretto";
		 error[1].style.color = "darkgreen";
		 return true; //qui ritorna true
	 }
 }
 
 function checkSex(){ //funzione che controlla l'inserimento del sesso
	 var sex = document.form.sex; //creo la variabile dove vado a passare l'input (radice è document, form sarebbe nome del form, sex sarebbe il nome dell'attr di input)
	 var error = document.getElementsByClassName("eSex"); //creo la var che funge da errore prendendo via l'attr id l'elemento span
	 
	 if(sex.value == ""){ //controlla se non è nullo
	 	error[0].innerHTML = "Inserisci il sesso"; //dentro a span con la funzione innerHTML scrive quello che passi come stringa
	 	error[0].style.color = "#DC5959"; //lo stilizza con un colore hex
		return false; //e ritorna false
	 }
	 else{ //nel caso non è nullo
		 error[0].innerHTML = "Corretto";
		 error[0].style.color = "darkgreen";
		 return true; //qui ritorna true
	 }
 }
 
 function checkBirthDate(){
    var error = document.getElementsByClassName("eBirthDate");

    var date = document.form.birthDate;
    var data_corrente = new Date(); //imposto la data corrente: di default prende la data di oggi

    if(date.value == ""){ //controlla prima se la data input è stata inserita
        error[0].innerHTML = "Inserisci la data di nascita";
        error[0].style.color = "#DC5959";
        return false;
    }
 
    var data_immessa = new Date(date.value);  //imposto la data immessa

    var differenza = data_corrente - data_immessa; //faccio la differenza 

    var eta = differenza / (1000 * 60 * 60 * 24 * 365.25); //in anni millisecondi

    if(eta<18){
        error[0].innerHTML="Non sei maggiorenne";
        error[0].style.color="#DC5959";
        return false;
    }
    else{
        error[0].innerHTML = "Giusto";
        error[0].style.color = "darkgreen";
        return true;
    }
 }
 
 function checkUsername(){
    var username = document.form.username;
    var check = new RegExp('^[a-z0-9]{3,90}$', 'i');
    var error = document.getElementsByClassName("eUsername");

    if(!check.test(username.value)){
        error[0].innerHTML = "Inserisci l'username corretto";
        error[0].style.color="#DC5959";
        return false;
    }
    else{
		error[0].innerHTML = "Giusto";
		error[0].style.color = "darkgreen";
		return true;
    }

 }
 
 function checkEmail(){
    var email = document.form.email;
    var error = document.getElementsByClassName("eEmail");

    if(!email.value.endsWith("@gmail.com")){ //se finisce con @gmail.com
        error[0].innerHTML = "Inserisci l'email valida";
        error[0].style.color="#DC5959";
        return false;
    }
    else{
		error[0].innerHTML = "Giusto";
		error[0].style.color = "darkgreen";
		return true;
    }

 }
 
 function checkPassword(){
    var password = document.form.password;
    var check= new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%])(?=.*[0-9]).{8,20}$');
    var error = document.getElementsByClassName("ePassword");

    if(!check.test(password.value)){
        error[0].innerHTML = "Inserisci la pwd corretta";
        error[0].style.color="#DC5959";
        return false;
    }
    else{
		error[0].innerHTML = "Giusto";
		error[0].style.color = "darkgreen";
		return true;
    }

 }
 
 function checkConfPassword(){
    var conf_password = document.form.confPassword;
    var password = document.form.password;
    var error = document.getElementsByClassName("eConfPassword");

    if(conf_password.value == "" || password.value != conf_password.value){ //se non sono uguali
        error[0].innerHTML = "Le password non coincidono";
        error[0].style.color="#DC5959";
        return false;
    }
    else{
		error[0].innerHTML = "Giusto";
		error[0].style.color = "darkgreen";
		return true;
    }

 }
 
 function checkText(){
	 var text = document.form.text;
	 var check = new RegExp('^.{1,140}$', 'i');
	 var error = document.getElementsByClassName("eText");
	 
	 if(!check.test(text.value)){
		error[0].innerHTML = "Il testo deve essere min 1, max 140 caratteri";
        error[0].style.color="#DC5959";
        return false;
	 }
	 else{
		error[0].innerHTML = "Giusto";
		error[0].style.color = "darkgreen";
		return true;
	 }
 }
 
 function checkHashtag(){
	 var hashtag = document.form.hashtag;
	 var check = new RegExp('^[A-Z0-9]{1,140}$');
	 var error = document.getElementsByClassName("eHashtag");
	 
	 if(!check.test(hashtag.value)){
		error[0].innerHTML = "Il testo non deve contenere spazi e deve essere min 1, max 140 caratteri";
        error[0].style.color="#DC5959";
        return false;
	 }
	 else{
		error[0].innerHTML = "Giusto";
		error[0].style.color = "darkgreen";
		return true;
	 }
 }
 
 function checkString(){ //sia per hashtag che per parola
	 var string = document.form.string;
	 var check = new RegExp('^.{1,140}$');
	 var error = document.getElementsByClassName("eString");
	 
	 if(!check.test(string.value)){
		error[0].innerHTML = "Il testo deve essere min 1 max 140 caratteri";
        error[0].style.color="#DC5959";
        return false;
	 }
	 else{
		error[0].innerHTML = "Giusto";
		error[0].style.color = "darkgreen";
		return true;
	 }
 }
 
 function sendFormRegister(){
	 var flag;
	 var error = document.getElementsByClassName("eForm");
	 
	 var functions = [checkName, checkSurname, checkSex, checkBirthDate, checkUsername, checkEmail, checkPassword, checkConfPassword];
	 var results = [];
	 
	 for(var i=0; i<functions.length; i++){
		 flag = functions[i]();//incapsula i risultati booleani
		 results[i] = flag;
	 }
	 
	 if(results.includes(false)){ //se contiene almeno un false
		 error[0].innerHTML = "Qualcosa è andato storto";
		 error[0].style.color = "#DC5959";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "darkgreen";
	 return true;
 }
 
 function sendFormLogin(){
	 var flag;
	 var error = document.getElementsByClassName("eForm");
	 
	 var functions = [checkUsername, checkPassword];
	 var results = [];
	 
	 for(var i=0; i<functions.length; i++){
		 flag = functions[i]();
		 results[i] = flag;
	 }
	 
	 if(results.includes(false)){
		 error[0].innerHTML = "Qualcosa è andato storto";
		 error[0].style.color = "#DC5959";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "darkgreen";
	 return true;
 }
 
 
 function sendFormPublish(){
	 var flag;
	 var error = document.getElementsByClassName("eForm");
	 
	 var functions = [checkText, checkHashtag];
	 var results = [];
	 
	 for(var i=0; i<functions.length; i++){
		 flag = functions[i]();
		 results[i] = flag;
	 }
	 
	 if(results.includes(false)){
		 error[0].innerHTML = "Qualcosa è andato storto";
		 error[0].style.color = "white";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "white";
	 return true;
 }
 
 function sendFormSearch(){
	 var flag;
	 var error = document.getElementsByClassName("eForm");
	 
	 var functions = [checkUsername];
	 var results = [];
	 
	 for(var i=0; i<functions.length; i++){
		 flag = functions[i]();
		 results[i] = flag;
	 }
	 
	 if(results.includes(false)){
		 error[0].innerHTML = "Qualcosa è andato storto";
		 error[0].style.color = "#DC5959";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "darkgreen";
	 return true;
 }
 
 function sendFormString(){
	 var flag;
	 var error = document.getElementsByClassName("eForm");
	 
	 var functions = [checkString];
	 var results = [];
	 
	 for(var i=0; i<functions.length; i++){
		 flag = functions[i]();
		 results[i] = flag;
	 }
	 
	 if(results.includes(false)){
		 error[0].innerHTML = "Qualcosa è andato storto";
		 error[0].style.color = "#DC5959";
		 return false;
	 }
	 
	 error.innerHTML = "Invio del form in corso..."
	 error.style.color = "darkgreen";
	 return true;
 }
 
 
 