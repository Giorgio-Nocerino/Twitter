package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.CountDTO;
import model.ListDTO;

/**
 * Servlet implementation class CountSentReceivedMsg
 */
@WebServlet("/CountSentReceivedMsg")
public class CountSentReceivedMsg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CountSentReceivedMsg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		RequestDispatcher rd; //interfaccia che prepara la response da inviare al file html per esempio messaggi di testo, oggetti ecc...
		
		DBManageCountSentReceivedMsg dbGetCountSentReceivedMsg = new DBManageCountSentReceivedMsg();
		ArrayList<CountDTO> arrCountSent = new ArrayList<CountDTO>();
		CountDTO countDTO = null;
		
		arrCountSent = dbGetCountSentReceivedMsg.getCountSentReceivedMsg(arrCountSent, countDTO, "sent"); //ricavo il numero di messaggi inviati
		
		ArrayList<CountDTO> arrCountReceived = new ArrayList<CountDTO>();
		countDTO = null;
		
		arrCountReceived = dbGetCountSentReceivedMsg.getCountSentReceivedMsg(arrCountReceived, countDTO, "received"); //ricavo il numero di messaggi ricevuti
		
		if(arrCountSent.size() > 0 && arrCountReceived.size() > 0) { //se ha inviato almeno 1 messaggio e ha ricevuto almeno 1
			
			request.setAttribute("countSent", arrCountSent);
			request.setAttribute("areThereMsgSent", 1);
			request.setAttribute("areThereMsgReceived", 1);
			request.setAttribute("countReceived", arrCountReceived);
			rd = request.getRequestDispatcher("CountTweetListFile.jsp");
			rd.forward(request, response);
			
		}
		else if(arrCountSent.size() > 0 && arrCountReceived.size() == 0) { //se ha inviato almeno 1 messaggio ma 0 messaggi ricevuti
			
			request.setAttribute("countSent", arrCountSent);
			request.setAttribute("areThereMsgSent", 1);
			request.setAttribute("areThereMsgReceived", 0);
			rd = request.getRequestDispatcher("CountTweetListFile.jsp");
			rd.forward(request, response);
			
		}
		else if(arrCountSent.size() == 0 && arrCountReceived.size() > 0) { //se ha ricevuto almeno 1 messaggio ma 0 messaggi inviati
			
			request.setAttribute("areThereMsgSent", 0);
			request.setAttribute("areThereMsgReceived", 1);
			request.setAttribute("countReceived", arrCountReceived);
			rd = request.getRequestDispatcher("CountTweetListFile.jsp");
			rd.forward(request, response);
			
		}
		else { //se non ha ne inviato ne ricevuto messaggio
			request.setAttribute("areThereMsgSent", 0);
			request.setAttribute("areThereMsgReceived", 0);
			rd = request.getRequestDispatcher("CountTweetListFile.jsp");
			rd.forward(request, response);

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
