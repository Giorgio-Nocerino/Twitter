package interfaces;

import java.sql.ResultSet;

public interface URGetUtenteByOnlyUsername {

	ResultSet getUtenteByOnlyUsername(String username);
}
