package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import annotation.DocMetodo;
import model.CountDTO;
import model.MessaggioRepository;

public class DBGetCountByWord {

	@DocMetodo(descrizione = "Metodo che otteniamo in output il numero occorrenze di una parola desiderata")
	public ArrayList<CountDTO> getCountByWord(ArrayList<CountDTO> arrCountWord, CountDTO countDTO, String word) {
		ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)
		
		MessaggioRepository mr = new MessaggioRepository(); //istanzo il repository
		
		rs = mr.countByWord(word);
		
		try {
			while(rs.next()) { //next fa da puntatore per scorrere le righe del ResultSet (while perchè ci sono più righe)
				countDTO = new CountDTO(); //lo inizializzo
				countDTO.setNomeID(word); //prende il valore del ResultSet dalla determinata colonna db
				countDTO.setCount(rs.getInt("num_parola"));
				
				arrCountWord.add(countDTO); //aggiunge l'oggetto nell'arraylist apposito
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return arrCountWord;
	}
}
