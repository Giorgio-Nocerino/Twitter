package controller;

import java.sql.ResultSet;
import java.sql.SQLException;

import annotation.DocMetodo;
import model.Utente;
import model.UtenteRepository;

public class DBGetUtente {
	
	@DocMetodo(descrizione = "Metodo che otteniamo in output l'utente via username e password")
	public Utente getUtente(Utente u) {
		ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)
		
		UtenteRepository ur = new UtenteRepository(); //istanzo il repository
		
		rs = ur.getUtente(u); //richiamo il metodo
		u = new Utente(); //rinizializza
		
		try {
			if(rs.next()) { //next fa da puntatore per scorrere le righe del ResultSet (if perchè una sola riga)
				u.setUsername(rs.getString("u.username")); //prende il valore del ResultSet dalla determinata colonna db
				u.setPassword(rs.getString("u.pwd"));
				u.setNome(rs.getString("u.nome"));
				u.setCognome(rs.getString("u.cognome"));
				u.setSesso(rs.getString("u.sesso"));
				u.setTipoPermesso(rs.getString("p.tipo"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return u;
	}
}
