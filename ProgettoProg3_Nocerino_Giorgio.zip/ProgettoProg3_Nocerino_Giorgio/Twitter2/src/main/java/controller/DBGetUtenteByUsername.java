package controller;

import java.sql.ResultSet;
import java.sql.SQLException;

import annotation.DocMetodo;
import model.Utente;
import model.UtenteRepository;

public class DBGetUtenteByUsername {
	
	@DocMetodo(descrizione = "Metodo che otteniamo in output l'utente dall'username")
	public Utente getUtenteByUsername(String username) {
		ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)
		Utente u = new Utente();
		UtenteRepository ur = new UtenteRepository();
		
		rs = ur.getUtenteByOnlyUsername(username);
		
		try {
			if(rs.next()) { //next fa da puntatore per scorrere le righe del ResultSet (if perchè c'è una sola riga)
				u.setUsername(rs.getString("u.username")); //prende il valore del ResultSet dalla determinata colonna db
				u.setPassword(rs.getString("u.pwd"));
				u.setNome(rs.getString("u.nome"));
				u.setCognome(rs.getString("u.cognome"));
				u.setSesso(rs.getString("u.sesso"));
				u.setTipoPermesso(rs.getString("p.tipo"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return u;
	}
}
