package model;

import java.sql.Date;
import java.util.Objects;

public class MessaggioDTO {
	
	private String testo;
	private Date dataPub;
	private String username;
	private String nomeHT;
	
	public String getTesto() {
		return testo;
	}
	public void setTesto(String testo) {
		this.testo = testo;
	}
	public Date getDataPub() {
		return dataPub;
	}
	public void setDataPub(Date dataPub) {
		this.dataPub = dataPub;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getNomeHT() {
		return nomeHT;
	}
	public void setNomeHT(String nomeHT) {
		this.nomeHT = nomeHT;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(dataPub, nomeHT, testo, username);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MessaggioDTO other = (MessaggioDTO) obj;
		return Objects.equals(dataPub, other.dataPub) && Objects.equals(nomeHT, other.nomeHT)
				&& Objects.equals(testo, other.testo) && Objects.equals(username, other.username);
	}
	
	public MessaggioDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public MessaggioDTO(String testo, Date dataPub, String username, String nomeHT) {
		super();
		this.testo = testo;
		this.dataPub = dataPub;
		this.username = username;
		this.nomeHT = nomeHT;
	}
	
	

}
