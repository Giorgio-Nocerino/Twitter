package controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Hashtag;
import model.HashtagRepository;
import model.Messaggio;
import model.MessaggioRepository;
import model.Utente;
import model.UtenteRepository;

/**
 * Servlet implementation class InsertMessaggio
 */
@WebServlet("/InsertMessaggio")
public class InsertMessaggio extends DBGetCountEveryHashtag {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertMessaggio() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession(); //richiamo la sessione precedentemente creata
		RequestDispatcher rd; //interfaccia che prepara la response da inviare al file html per esempio messaggi di testo, oggetti ecc...
		ResultSet rs; //interfaccia che da come risultato una collection di righe (sorta di vista)

		
		Messaggio m = new Messaggio();
		Utente u = new Utente(); //inizializzo gli oggetti che mi servono
		Hashtag h = new Hashtag();
		
		MessaggioRepository mr;
		UtenteRepository ur; //setto le variabili repository
		HashtagRepository hr;
		DBManageInsert dm;
		DBManageGetID dbGetID;
		
		u = (Utente) session.getAttribute("user"); //recupero il valore della session con il metodo getAttribute e lo casto a Utente

		if(u != null) { //se esiste allora procedo con il tweet altrimenti errore
			
			dm = new DBManageInsert();
			dbGetID = new DBManageGetID();
			
			rs = null;
			ur = new UtenteRepository(); //inizializzo UtenteRepository
			
			Integer idUsername = 0;			
			idUsername = dbGetID.getID(u);//recupero l'id dell'username
			
			
			m.setTesto(request.getParameter("text"));
			m.setDataPub(Date.valueOf(LocalDate.now())); //recupero i parametri inseriti dall'utente
			h.setNome("#" + request.getParameter("hashtag"));
			
			rs = null; //rinizializzo	
			hr = new HashtagRepository();  //inizializzo l'HashtagRepository
			
			Integer idHashtag = 0;
			idHashtag = dbGetID.getID(h); //recupero l'id del nome hashtag
			
			Boolean isThere = false;
			Integer num = 0;
			
			if(idHashtag != 0) { //controllo se esiste: se TRUE allora passo all'inizializzazione del tweet
				isThere = true; //se invece è FALSE allora inserisco il nuovo hashtag e recupera l'id
			}
			else{
				num = dm.insertIntoUHM(h, null, null);
				
				if(num > 0) {
					
					idHashtag = 0;
					idHashtag = dbGetID.getID(h); //recupero l'id del nome hashtag
					
					isThere = true;
				}
				else {
					isThere = false;
				}
			}
			
			if(isThere) { //se è TRUE allora inizializzo MessaggioRepository
				mr = new MessaggioRepository();
				
				num = 0;
				num = dm.insertIntoUHM(m, idUsername, idHashtag);
			
				if(num > 0) { //se è TRUE allora preparo il messaggio positivo, altrimenti negativo
					request.setAttribute("msg", "TWEET PUBBLICATO CON SUCCESSO");
					rd = request.getRequestDispatcher("Success.jsp");
					rd.forward(request, response);
				}
				else {
					request.setAttribute("msg", "PUBBLICAZIONE TWEET FALLITA");
					rd = request.getRequestDispatcher("Fail.jsp");
					rd.forward(request, response);
				}
				
			}
			else { //altrimenti è FALSE poichè non c'è l'hashtag e non è stato creato
				request.setAttribute("msg", "IMPOSSIBILE TROVARE L'HASHTAG");
				rd = request.getRequestDispatcher("Fail.jsp");
				rd.forward(request, response);
			}
			
		}
		else { //FALSE nel caso la sessione è scaduta
			request.setAttribute("msg", "ERRORE: SESSIONE SCADUTA");
			rd = request.getRequestDispatcher("Fail.jsp");
			rd.forward(request, response);
		}
		
		
	}

}
