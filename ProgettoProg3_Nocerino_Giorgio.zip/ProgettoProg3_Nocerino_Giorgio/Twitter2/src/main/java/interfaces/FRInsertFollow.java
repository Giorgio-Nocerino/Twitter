package interfaces;

public interface FRInsertFollow {

	public int insertFollow(Integer idFollower, Integer idFollow);
}
