package interfaces;

import java.sql.ResultSet;

public interface MRGetNumMsgInviati {

	ResultSet getCountNumMsgInviati();
}
