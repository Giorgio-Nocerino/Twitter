package controller;

import java.io.IOException;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.FollowerRepository;
import model.Utente;
import model.UtenteRepository;

/**
 * Servlet implementation class FollowerRepository
 */
@WebServlet("/InsertFollow")
public class InsertFollow extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertFollow() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Utente u = new Utente();
		DBInsertFollow dbInsertFollow;
		DBManageGetID dbIDUser;
		RequestDispatcher rd; //interfaccia che prepara la response da inviare al file html per esempio messaggi di testo, oggetti ecc...
		
		u.setUsername(request.getParameter("nameFollower")); //recupera la richiesta con il metodo getParameter
		
		dbIDUser = new DBManageGetID();
		Integer idUsernameFollower = dbIDUser.getID(u); //ottengo l'id dell'username loggato
		
		u= new Utente(); //rinizializzo
		u.setUsername(request.getParameter("nameFollow")); 
		
		Integer idUsernameFollow = dbIDUser.getID(u);//ottengo l'id dell'username ricercato
		
		if(idUsernameFollower != null && idUsernameFollow != null) {
			dbInsertFollow = new DBInsertFollow();
			Integer num = 0;
			
			num = dbInsertFollow.insertFollow(idUsernameFollower, idUsernameFollow); //richiamo il metodo passando sia l'id del follower che del follow
			
			if(num > 0) {
				request.setAttribute("msg", "HAI SEGUITO QUESTO UTENTE");
				rd = request.getRequestDispatcher("Success.jsp");
				rd.forward(request, response);
			}
			else {
				request.setAttribute("msg", "QUALCOSA È ANDATO STORTO");
				rd = request.getRequestDispatcher("Fail.jsp");
				rd.forward(request, response);
			}
		}
		else {
			request.setAttribute("msg", "NON È PRESENTE IL PROFILO FOLLOW O IL PROFILO UTENTE");
			rd = request.getRequestDispatcher("Fail.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
