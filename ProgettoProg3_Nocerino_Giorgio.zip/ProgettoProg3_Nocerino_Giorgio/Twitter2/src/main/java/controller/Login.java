package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Utente;
import model.UtenteRepository;

/**
 * Servlet implementation class Loginia
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(); //preparo la sessione così i dati persisteranno
		
		Utente u = new Utente();
		DBGetUtente dbUtente = new DBGetUtente();
		
		u.setUsername(request.getParameter("username")); //metodo che prende i valori dal parametro (attributo name del tag input)
		u.setPassword(request.getParameter("password"));
		
		System.out.println(u.getUsername() + ", " + u.getPassword());
		
		RequestDispatcher rd; //interfaccia che prepara la response da inviare al file html per esempio messaggi di testo, oggetti ecc...
		
		u = dbUtente.getUtente(u); //richiamo il metodo per ottenere l'utente
		
		if(u.getUsername() != null && u.getPassword() != null) { //se esiste l'username e la password dell'utente
			session.setAttribute("user", u); //preparo la session dove contiene il messaggio costituito da etichetta e valore
			request.setAttribute("msg", "LOGIN EFFETTUATO CON SUCCESSO");
			rd = request.getRequestDispatcher("Success.jsp");
			rd.forward(request, response);
		}
		else {
			request.setAttribute("msg", "USERNAME E/O PASSWORD NON VALIDI");
			rd = request.getRequestDispatcher("FailLogin.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
