package model;

import java.util.Objects;

public class CountDTO {

	private String nomeID;
	private Integer count;
	
	public String getNomeID() {
		return nomeID;
	}
	public void setNomeID(String nomeID) {
		this.nomeID = nomeID;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	@Override
	public int hashCode() {
		return Objects.hash(count, nomeID);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CountDTO other = (CountDTO) obj;
		return Objects.equals(count, other.count) && Objects.equals(nomeID, other.nomeID);
	}
	
	public CountDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CountDTO(String nomeID, Integer count) {
		super();
		this.nomeID = nomeID;
		this.count = count;
	}
	
	
	
}
