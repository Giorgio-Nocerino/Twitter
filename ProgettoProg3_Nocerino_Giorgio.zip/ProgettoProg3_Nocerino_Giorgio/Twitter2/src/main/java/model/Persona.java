package model;

import java.sql.Date;
import java.util.Objects;

public class Persona {

	private String nome;
	private String cognome;
	private String sesso;
	private Date dataNascita;
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getSesso() {
		return sesso;
	}
	public void setSesso(String sesso) {
		this.sesso = sesso;
	}
	public Date getDataNascita() {
		return dataNascita;
	}
	public void setDataNascita(Date dataNascita) {
		this.dataNascita = dataNascita;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(cognome, dataNascita, nome, sesso);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Persona other = (Persona) obj;
		return Objects.equals(cognome, other.cognome) && Objects.equals(dataNascita, other.dataNascita)
				&& Objects.equals(nome, other.nome) && Objects.equals(sesso, other.sesso);
	}
	
	public Persona() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Persona(String nome, String cognome, String sesso, Date dataNascita) {
		super();
		this.nome = nome;
		this.cognome = cognome;
		this.sesso = sesso;
		this.dataNascita = dataNascita;
	}
	
	
}
