package interfaces;

import java.sql.ResultSet;

public interface HRCountEveryHashtag {
	ResultSet countEveryHashtag();
}
